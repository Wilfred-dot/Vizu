import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState('');
  const [carregando, setCarregando] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErro('');
    setCarregando(true);
    try {
      await login(email, senha);
      navigate('/dashboard');
    } catch (err) {
      setErro(err.response?.data?.erro || 'Erro ao fazer login');
    } finally {
      setCarregando(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh', display: 'flex',
      background: 'linear-gradient(135deg, #0A2540 0%, #1A5276 50%, #2E86AB 100%)',
    }}>
      {/* Lado esquerdo – branding */}
      <div style={{
        flex: 1, display: 'flex', flexDirection: 'column',
        justifyContent: 'center', padding: '60px', color: '#fff',
        display: window.innerWidth < 768 ? 'none' : 'flex',
      }}>
        <div style={{ fontSize: 56, marginBottom: 16 }}>👁</div>
        <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: 42, fontWeight: 700, marginBottom: 16, lineHeight: 1.2 }}>
          OftalmoCare
        </h1>
        <p style={{ fontSize: 18, opacity: 0.8, maxWidth: 380, lineHeight: 1.7 }}>
          Sistema de Gestão de Saúde Oftalmológica da cidade da Beira, Moçambique.
        </p>
        <div style={{ marginTop: 48, display: 'flex', gap: 32 }}>
          {[
            { valor: 'Digital', label: 'Fichas & Registos' },
            { valor: 'Seguro', label: 'RBAC & JWT' },
            { valor: 'Rápido', label: 'Agendamento Online' },
          ].map(s => (
            <div key={s.label}>
              <div style={{ fontSize: 20, fontWeight: 700 }}>{s.valor}</div>
              <div style={{ fontSize: 13, opacity: 0.6 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Lado direito – formulário */}
      <div style={{
        width: 440, background: '#fff', display: 'flex',
        flexDirection: 'column', justifyContent: 'center', padding: '60px 48px',
      }}>
        <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: 28, color: '#0A2540', marginBottom: 8 }}>
          Bem-vindo de volta
        </h2>
        <p style={{ color: '#5A6A7E', marginBottom: 32, fontSize: 14 }}>
          Entre com as suas credenciais para continuar
        </p>

        {erro && <div className="alert alert-erro">{erro}</div>}

        <form onSubmit={handleSubmit}>
          <div className="form-grupo">
            <label>Email</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)}
              placeholder="seu@email.com" required />
          </div>
          <div className="form-grupo">
            <label>Senha</label>
            <input type="password" value={senha} onChange={e => setSenha(e.target.value)}
              placeholder="••••••••" required />
          </div>
          <button type="submit" className="btn btn-primario" disabled={carregando}
            style={{ width: '100%', justifyContent: 'center', padding: '12px', marginTop: 8 }}>
            {carregando ? 'A entrar...' : 'Entrar'}
          </button>
        </form>

        <div style={{ marginTop: 32, padding: '16px', background: '#F0F4F8', borderRadius: 8, fontSize: 12, color: '#5A6A7E' }}>
          <div style={{ fontWeight: 600, marginBottom: 6 }}>Contas de demonstração:</div>
          <div>admin@oftalmologia.mz / admin123</div>
          <div>joao.henriques@oftalmologia.mz / medico123</div>
          <div>ana.machava@oftalmologia.mz / recepcao123</div>
        </div>
      </div>
    </div>
  );
}
