import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';

export default function Pacientes() {
  const navigate = useNavigate();
  const [pacientes, setPacientes] = useState([]);
  const [busca, setBusca] = useState('');
  const [carregando, setCarregando] = useState(true);
  const [modalAberto, setModalAberto] = useState(false);
  const [form, setForm] = useState({ nome:'', email:'', telefone:'', data_nascimento:'', genero:'', morada:'', bairro:'', bi_numero:'' });
  const [salvando, setSalvando] = useState(false);
  const [msg, setMsg] = useState('');

  const carregar = (b = '') => {
    setCarregando(true);
    api.get(`/pacientes?busca=${b}&limite=50`)
      .then(r => setPacientes(r.data.dados || []))
      .finally(() => setCarregando(false));
  };

  useEffect(() => { carregar(); }, []);

  const handleBusca = (e) => {
    setBusca(e.target.value);
    clearTimeout(window._debounce);
    window._debounce = setTimeout(() => carregar(e.target.value), 400);
  };

  const handleSalvar = async (e) => {
    e.preventDefault();
    setSalvando(true);
    setMsg('');
    try {
      await api.post('/pacientes', form);
      setMsg('sucesso');
      setModalAberto(false);
      carregar(busca);
      setForm({ nome:'', email:'', telefone:'', data_nascimento:'', genero:'', morada:'', bairro:'', bi_numero:'' });
    } catch (err) {
      setMsg(err.response?.data?.erro || 'Erro ao guardar');
    } finally {
      setSalvando(false);
    }
  };

  return (
    <div className="fade-in">
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:24 }}>
        <div>
          <h1 style={{ fontFamily:'Playfair Display, serif', fontSize:26, color:'#0A2540' }}>Pacientes</h1>
          <p style={{ color:'#5A6A7E', marginTop:4 }}>{pacientes.length} pacientes registados</p>
        </div>
        <button className="btn btn-primario" onClick={() => setModalAberto(true)}>+ Novo Paciente</button>
      </div>

      {msg === 'sucesso' && <div className="alert alert-sucesso">Paciente registado com sucesso!</div>}

      <div className="card">
        <div style={{ marginBottom:16 }}>
          <input value={busca} onChange={handleBusca} placeholder="🔍  Pesquisar por nome ou nº processo..."
            style={{ width:'100%', padding:'10px 14px', border:'1.5px solid #D6E4F0', borderRadius:8, fontFamily:'DM Sans, sans-serif', fontSize:14 }} />
        </div>

        {carregando ? (
          <div style={{ display:'flex', justifyContent:'center', padding:40 }}><div className="spinner"/></div>
        ) : pacientes.length === 0 ? (
          <div style={{ textAlign:'center', color:'#5A6A7E', padding:'40px 0' }}>
            <div style={{ fontSize:40 }}>👤</div>
            <div>Nenhum paciente encontrado</div>
          </div>
        ) : (
          <div style={{ overflowX:'auto' }}>
            <table className="tabela">
              <thead>
                <tr>
                  <th>Nº Processo</th>
                  <th>Nome</th>
                  <th>Data Nasc.</th>
                  <th>Género</th>
                  <th>Bairro</th>
                  <th>Telefone</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody>
                {pacientes.map(p => (
                  <tr key={p.id}>
                    <td><code style={{ background:'#F0F4F8', padding:'2px 6px', borderRadius:4, fontSize:12 }}>{p.num_processo}</code></td>
                    <td><strong>{p.nome}</strong></td>
                    <td>{p.data_nascimento ? new Date(p.data_nascimento).toLocaleDateString('pt-MZ') : '—'}</td>
                    <td style={{ textTransform:'capitalize' }}>{p.genero || '—'}</td>
                    <td>{p.bairro || '—'}</td>
                    <td>{p.telefone || '—'}</td>
                    <td>
                      <button className="btn btn-secundario btn-sm"
                        onClick={() => navigate(`/historico/${p.id}`)}>
                        📋 Histórico
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modal Novo Paciente */}
      {modalAberto && (
        <div className="modal-overlay" onClick={() => setModalAberto(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h2 className="modal-titulo">Registar Novo Paciente</h2>
            {typeof msg === 'string' && msg && msg !== 'sucesso' && <div className="alert alert-erro">{msg}</div>}
            <form onSubmit={handleSalvar}>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
                {[
                  { key:'nome', label:'Nome Completo', tipo:'text', req:true },
                  { key:'email', label:'Email', tipo:'email', req:true },
                  { key:'telefone', label:'Telefone', tipo:'tel' },
                  { key:'data_nascimento', label:'Data de Nascimento', tipo:'date', req:true },
                  { key:'bi_numero', label:'Nº BI', tipo:'text' },
                  { key:'bairro', label:'Bairro', tipo:'text' },
                ].map(f => (
                  <div key={f.key} className="form-grupo" style={{ margin:0 }}>
                    <label>{f.label}</label>
                    <input type={f.tipo} value={form[f.key]} required={f.req}
                      onChange={e => setForm({...form, [f.key]: e.target.value})} />
                  </div>
                ))}
                <div className="form-grupo" style={{ margin:0 }}>
                  <label>Género</label>
                  <select value={form.genero} onChange={e => setForm({...form, genero: e.target.value})}>
                    <option value="">Seleccionar...</option>
                    <option value="masculino">Masculino</option>
                    <option value="feminino">Feminino</option>
                    <option value="outro">Outro</option>
                  </select>
                </div>
                <div className="form-grupo" style={{ margin:0, gridColumn:'span 2' }}>
                  <label>Morada</label>
                  <input type="text" value={form.morada} onChange={e => setForm({...form, morada: e.target.value})} />
                </div>
              </div>
              <div style={{ display:'flex', gap:12, marginTop:24 }}>
                <button type="button" className="btn btn-secundario" onClick={() => setModalAberto(false)}>Cancelar</button>
                <button type="submit" className="btn btn-primario" disabled={salvando}>
                  {salvando ? 'A guardar...' : 'Registar Paciente'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
