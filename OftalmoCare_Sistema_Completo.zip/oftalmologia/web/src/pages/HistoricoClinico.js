import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../services/api';

export default function HistoricoClinico() {
  const { pacienteId } = useParams();
  const navigate = useNavigate();
  const [historico, setHistorico] = useState([]);
  const [paciente, setPaciente] = useState(null);
  const [receitas, setReceitas] = useState([]);
  const [aba, setAba] = useState('historico');
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    Promise.all([
      api.get(`/pacientes/${pacienteId}`),
      api.get(`/historico/paciente/${pacienteId}`),
      api.get(`/receitas/paciente/${pacienteId}`),
    ]).then(([p, h, r]) => {
      setPaciente(p.data);
      setHistorico(h.data);
      setReceitas(r.data);
    }).finally(() => setCarregando(false));
  }, [pacienteId]);

  if (carregando) return <div style={{ display:'flex', justifyContent:'center', padding:60 }}><div className="spinner"/></div>;
  if (!paciente) return <div className="alert alert-erro">Paciente não encontrado</div>;

  return (
    <div className="fade-in">
      <button className="btn btn-secundario btn-sm" onClick={() => navigate('/pacientes')} style={{ marginBottom:16 }}>← Pacientes</button>

      {/* Info do paciente */}
      <div className="card" style={{ marginBottom:20 }}>
        <div style={{ display:'flex', alignItems:'center', gap:20 }}>
          <div style={{ width:64, height:64, borderRadius:'50%', background:'linear-gradient(135deg,#0A2540,#2E86AB)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:28, color:'#fff' }}>
            👤
          </div>
          <div>
            <h2 style={{ fontFamily:'Playfair Display,serif', fontSize:22, color:'#0A2540' }}>{paciente.nome}</h2>
            <div style={{ color:'#5A6A7E', fontSize:13, marginTop:4 }}>
              <span style={{ marginRight:16 }}>📋 {paciente.num_processo}</span>
              <span style={{ marginRight:16 }}>📅 {paciente.data_nascimento && new Date(paciente.data_nascimento).toLocaleDateString('pt-MZ')}</span>
              <span style={{ marginRight:16 }}>📍 {paciente.bairro || 'Beira'}</span>
              {paciente.tipo_sanguineo && <span>🩸 {paciente.tipo_sanguineo}</span>}
            </div>
            {paciente.alergias && (
              <div style={{ marginTop:6, padding:'4px 10px', background:'#FEE2E2', borderRadius:6, fontSize:12, color:'#991B1B', display:'inline-block' }}>
                ⚠️ Alergias: {paciente.alergias}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Abas */}
      <div style={{ display:'flex', gap:4, marginBottom:16, background:'#fff', padding:4, borderRadius:10, boxShadow:'var(--sombra)', width:'fit-content' }}>
        {[{k:'historico', l:'📋 Histórico Clínico'},{k:'receitas', l:'💊 Receitas'}].map(a => (
          <button key={a.k} onClick={() => setAba(a.k)} className="btn"
            style={{ background: aba===a.k ? '#0A2540' : 'transparent', color: aba===a.k ? '#fff' : '#5A6A7E' }}>
            {a.l}
          </button>
        ))}
      </div>

      {aba === 'historico' && (
        <div>
          {historico.length === 0 ? (
            <div className="card" style={{ textAlign:'center', color:'#5A6A7E', padding:'40px 0' }}>
              <div style={{ fontSize:40 }}>📋</div>
              <div>Nenhum histórico clínico disponível</div>
            </div>
          ) : historico.map(h => (
            <div key={h.id} className="card" style={{ marginBottom:12 }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:12 }}>
                <div>
                  <span style={{ fontFamily:'Playfair Display,serif', fontSize:17, color:'#0A2540' }}>{h.diagnostico}</span>
                  {h.cid10 && <code style={{ marginLeft:8, background:'#F0F4F8', padding:'2px 6px', borderRadius:4, fontSize:12 }}>{h.cid10}</code>}
                </div>
                <span style={{ color:'#5A6A7E', fontSize:13 }}>{new Date(h.data_atendimento).toLocaleDateString('pt-MZ')} — Dr. {h.medico_nome}</span>
              </div>
              {h.queixa_principal && <p style={{ color:'#5A6A7E', marginBottom:8 }}><strong>Queixa:</strong> {h.queixa_principal}</p>}
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:8 }}>
                {h.acuidade_visual_od && <div style={{ background:'#F0F4F8', padding:'8px 12px', borderRadius:8 }}><strong>AV OD:</strong> {h.acuidade_visual_od}</div>}
                {h.acuidade_visual_oe && <div style={{ background:'#F0F4F8', padding:'8px 12px', borderRadius:8 }}><strong>AV OE:</strong> {h.acuidade_visual_oe}</div>}
              </div>
              {h.tratamento && <p style={{ marginBottom:4 }}><strong>Tratamento:</strong> {h.tratamento}</p>}
              {h.plano_retorno && <p style={{ color:'#2E86AB' }}><strong>Retorno:</strong> {h.plano_retorno}</p>}
            </div>
          ))}
        </div>
      )}

      {aba === 'receitas' && (
        <div>
          {receitas.length === 0 ? (
            <div className="card" style={{ textAlign:'center', color:'#5A6A7E', padding:'40px 0' }}>
              <div style={{ fontSize:40 }}>💊</div>
              <div>Nenhuma receita disponível</div>
            </div>
          ) : receitas.map(r => (
            <div key={r.id} className="card" style={{ marginBottom:12 }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:12 }}>
                <span style={{ fontFamily:'Playfair Display,serif', fontSize:17, color:'#0A2540' }}>Receita Médica</span>
                <span style={{ color:'#5A6A7E', fontSize:13 }}>{new Date(r.data_emissao).toLocaleDateString('pt-MZ')} — Dr. {r.medico_nome}</span>
              </div>
              <div style={{ background:'#F0F4F8', borderRadius:8, padding:12 }}>
                {(r.itens || []).filter(i => i.medicamento).map((item, idx) => (
                  <div key={idx} style={{ padding:'8px 0', borderBottom: idx < r.itens.length-1 ? '1px solid #D6E4F0' : 'none' }}>
                    <strong>{item.medicamento}</strong>
                    {item.dose && <span style={{ color:'#5A6A7E', marginLeft:8 }}>{item.dose}</span>}
                    {item.frequencia && <span style={{ color:'#5A6A7E' }}> – {item.frequencia}</span>}
                    {item.duracao && <span style={{ color:'#5A6A7E' }}> por {item.duracao}</span>}
                  </div>
                ))}
              </div>
              <div style={{ marginTop:8, fontSize:12, color:'#5A6A7E' }}>
                Válida por {r.validade_dias} dias
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
