import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';

export default function NovaConsulta() {
  const navigate = useNavigate();
  const [pacientes, setPacientes] = useState([]);
  const [medicos, setMedicos] = useState([]);
  const [slots, setSlots] = useState([]);
  const [form, setForm] = useState({ paciente_id:'', medico_id:'', data:'', hora:'', tipo:'consulta', motivo:'' });
  const [salvando, setSalvando] = useState(false);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    api.get('/pacientes?limite=200').then(r => setPacientes(r.data.dados || []));
    api.get('/medicos').then(r => setMedicos(r.data));
  }, []);

  useEffect(() => {
    if (form.medico_id && form.data) {
      api.get(`/medicos/${form.medico_id}/disponibilidade?data=${form.data}`)
        .then(r => setSlots(r.data));
    }
  }, [form.medico_id, form.data]);

  const handleSalvar = async (e) => {
    e.preventDefault();
    setSalvando(true);
    try {
      await api.post('/consultas', {
        ...form,
        data_hora: `${form.data}T${form.hora}:00`,
      });
      navigate('/consultas');
    } catch (err) {
      setMsg(err.response?.data?.erro || 'Erro ao agendar');
    } finally {
      setSalvando(false);
    }
  };

  return (
    <div className="fade-in" style={{ maxWidth:600, margin:'0 auto' }}>
      <button className="btn btn-secundario btn-sm" onClick={() => navigate(-1)} style={{ marginBottom:20 }}>← Voltar</button>
      <div className="card">
        <h2 className="modal-titulo">Agendar Nova Consulta</h2>
        {msg && <div className="alert alert-erro">{msg}</div>}
        <form onSubmit={handleSalvar}>
          <div className="form-grupo">
            <label>Paciente *</label>
            <select required value={form.paciente_id} onChange={e => setForm({...form, paciente_id: e.target.value})}>
              <option value="">Seleccionar paciente...</option>
              {pacientes.map(p => <option key={p.id} value={p.id}>{p.nome} — {p.num_processo}</option>)}
            </select>
          </div>
          <div className="form-grupo">
            <label>Médico *</label>
            <select required value={form.medico_id} onChange={e => setForm({...form, medico_id: e.target.value, hora:''})}>
              <option value="">Seleccionar médico...</option>
              {medicos.map(m => <option key={m.id} value={m.id}>{m.nome} – {m.especialidade}</option>)}
            </select>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
            <div className="form-grupo">
              <label>Data *</label>
              <input type="date" required value={form.data}
                min={new Date().toISOString().split('T')[0]}
                onChange={e => setForm({...form, data: e.target.value, hora:''})} />
            </div>
            <div className="form-grupo">
              <label>Hora *</label>
              <select required value={form.hora} onChange={e => setForm({...form, hora: e.target.value})}>
                <option value="">Seleccionar hora...</option>
                {slots.map(s => (
                  <option key={s.hora} value={s.hora} disabled={!s.disponivel}>
                    {s.hora} {!s.disponivel ? '(ocupado)' : ''}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="form-grupo">
            <label>Tipo de Consulta</label>
            <select value={form.tipo} onChange={e => setForm({...form, tipo: e.target.value})}>
              <option value="consulta">Consulta</option>
              <option value="retorno">Retorno</option>
              <option value="exame">Exame</option>
              <option value="cirurgia">Cirurgia</option>
              <option value="urgencia">Urgência</option>
            </select>
          </div>
          <div className="form-grupo">
            <label>Motivo / Observações</label>
            <textarea rows={3} value={form.motivo} onChange={e => setForm({...form, motivo: e.target.value})}
              placeholder="Descreva o motivo da consulta..." />
          </div>
          <div style={{ display:'flex', gap:12, marginTop:8 }}>
            <button type="button" className="btn btn-secundario" onClick={() => navigate(-1)}>Cancelar</button>
            <button type="submit" className="btn btn-primario" disabled={salvando}>
              {salvando ? 'A agendar...' : 'Confirmar Agendamento'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
