import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

const badgeStatus = (s) => <span className={`badge badge-${s}`}>{s.replace('_', ' ')}</span>;

export default function Dashboard() {
  const { usuario } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [erro, setErro] = useState('');

  useEffect(() => {
    api.get('/dashboard/stats')
      .then(r => setStats(r.data))
      .catch(() => setErro('Não foi possível carregar os dados'));
  }, []);

  if (erro) return <div className="alert alert-erro">{erro}</div>;
  if (!stats) return <div style={{ display: 'flex', justifyContent: 'center', padding: 60 }}><div className="spinner" /></div>;

  const cartoes = [
    { valor: stats.totalPacientes, label: 'Total de Pacientes', icone: '👤', cor: '#DBEAFE', corI: '#2563EB' },
    { valor: stats.consultasHoje, label: 'Consultas Hoje', icone: '📅', cor: '#FEF9C3', corI: '#CA8A04' },
    { valor: stats.agendadas, label: 'Aguardando', icone: '⏳', cor: '#FCE7F3', corI: '#DB2777' },
    { valor: stats.concluidas, label: 'Concluídas Hoje', icone: '✅', cor: '#DCFCE7', corI: '#16A34A' },
  ];

  return (
    <div className="fade-in">
      {/* Header */}
      <div style={{ marginBottom: 28 }}>
        <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: 26, color: '#0A2540' }}>
          Bom dia, {usuario?.nome?.split(' ')[0]} 👋
        </h1>
        <p style={{ color: '#5A6A7E', marginTop: 4 }}>Aqui está o resumo de hoje</p>
      </div>

      {/* Stat Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px,1fr))', gap: 16, marginBottom: 28 }}>
        {cartoes.map(c => (
          <div key={c.label} className="stat-card">
            <div className="icone" style={{ background: c.cor, color: c.corI }}>{c.icone}</div>
            <div>
              <div className="valor" style={{ color: '#0A2540' }}>{c.valor}</div>
              <div className="label">{c.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Próximas Consultas */}
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: 18, color: '#0A2540' }}>
            Consultas de Hoje
          </h2>
          <button className="btn btn-primario btn-sm" onClick={() => navigate('/consultas/nova')}>
            + Nova Consulta
          </button>
        </div>

        {stats.proximasConsultas.length === 0 ? (
          <div style={{ textAlign: 'center', color: '#5A6A7E', padding: '40px 0' }}>
            <div style={{ fontSize: 40, marginBottom: 8 }}>📭</div>
            Nenhuma consulta agendada para hoje
          </div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table className="tabela">
              <thead>
                <tr>
                  <th>Senha</th>
                  <th>Hora</th>
                  <th>Paciente</th>
                  <th>Processo</th>
                  <th>Médico</th>
                  <th>Tipo</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {stats.proximasConsultas.map(c => (
                  <tr key={c.id} style={{ cursor: 'pointer' }}
                    onClick={() => navigate(`/consultas`)}>
                    <td><strong>#{c.numero_senha}</strong></td>
                    <td>{new Date(c.data_hora).toLocaleTimeString('pt-MZ', { hour: '2-digit', minute: '2-digit' })}</td>
                    <td>{c.paciente_nome}</td>
                    <td><code style={{ background: '#F0F4F8', padding: '2px 6px', borderRadius: 4 }}>{c.num_processo}</code></td>
                    <td>{c.medico_nome}</td>
                    <td style={{ textTransform: 'capitalize' }}>{c.tipo}</td>
                    <td>{badgeStatus(c.status)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
