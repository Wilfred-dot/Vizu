import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';

const statusOpcoes = ['agendada','confirmada','em_atendimento','concluida','cancelada','falta'];

export default function Consultas() {
  const navigate = useNavigate();
  const [consultas, setConsultas] = useState([]);
  const [data, setData] = useState(new Date().toISOString().split('T')[0]);
  const [carregando, setCarregando] = useState(true);

  const carregar = () => {
    setCarregando(true);
    api.get(`/consultas?data=${data}&limite=100`)
      .then(r => setConsultas(r.data))
      .finally(() => setCarregando(false));
  };

  useEffect(() => { carregar(); }, [data]);

  const mudarStatus = async (id, status) => {
    await api.patch(`/consultas/${id}/status`, { status });
    carregar();
  };

  return (
    <div className="fade-in">
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:24 }}>
        <div>
          <h1 style={{ fontFamily:'Playfair Display, serif', fontSize:26, color:'#0A2540' }}>Consultas</h1>
          <p style={{ color:'#5A6A7E', marginTop:4 }}>{consultas.length} consulta(s) para esta data</p>
        </div>
        <div style={{ display:'flex', gap:12, alignItems:'center' }}>
          <input type="date" value={data} onChange={e => setData(e.target.value)}
            style={{ padding:'8px 12px', border:'1.5px solid #D6E4F0', borderRadius:8, fontFamily:'DM Sans,sans-serif' }} />
          <button className="btn btn-primario" onClick={() => navigate('/consultas/nova')}>+ Agendar</button>
        </div>
      </div>

      <div className="card">
        {carregando ? (
          <div style={{ display:'flex', justifyContent:'center', padding:40 }}><div className="spinner"/></div>
        ) : consultas.length === 0 ? (
          <div style={{ textAlign:'center', color:'#5A6A7E', padding:'40px 0' }}>
            <div style={{ fontSize:40 }}>📭</div>
            <div>Nenhuma consulta para esta data</div>
          </div>
        ) : (
          <div style={{ overflowX:'auto' }}>
            <table className="tabela">
              <thead>
                <tr>
                  <th>Senha</th><th>Hora</th><th>Paciente</th>
                  <th>Processo</th><th>Médico</th><th>Tipo</th>
                  <th>Status</th><th>Ações</th>
                </tr>
              </thead>
              <tbody>
                {consultas.map(c => (
                  <tr key={c.id}>
                    <td><strong style={{ fontSize:16 }}>#{c.numero_senha}</strong></td>
                    <td>{new Date(c.data_hora).toLocaleTimeString('pt-MZ', { hour:'2-digit', minute:'2-digit' })}</td>
                    <td>{c.paciente_nome}</td>
                    <td><code style={{ background:'#F0F4F8', padding:'2px 6px', borderRadius:4, fontSize:12 }}>{c.num_processo}</code></td>
                    <td>{c.medico_nome}</td>
                    <td style={{ textTransform:'capitalize' }}>{c.tipo}</td>
                    <td><span className={`badge badge-${c.status}`}>{c.status.replace('_',' ')}</span></td>
                    <td>
                      <select value={c.status}
                        onChange={e => mudarStatus(c.id, e.target.value)}
                        style={{ padding:'4px 8px', border:'1px solid #D6E4F0', borderRadius:6, fontSize:12 }}>
                        {statusOpcoes.map(s => <option key={s} value={s}>{s.replace('_',' ')}</option>)}
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
