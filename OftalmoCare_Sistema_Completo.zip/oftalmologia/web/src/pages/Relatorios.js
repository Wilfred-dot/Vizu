import React from 'react';

export default function Relatorios() {
  return (
    <div className="fade-in">
      <h1 style={{ fontFamily:'Playfair Display,serif', fontSize:26, color:'#0A2540', marginBottom:8 }}>Relatórios</h1>
      <p style={{ color:'#5A6A7E', marginBottom:24 }}>Análise e exportação de dados do sistema</p>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(280px,1fr))', gap:16 }}>
        {[
          { titulo:'Consultas por Período', desc:'Total de consultas por dia/semana/mês', icone:'📅' },
          { titulo:'Pacientes por Bairro', desc:'Distribuição geográfica dos pacientes', icone:'🗺️' },
          { titulo:'Diagnósticos Frequentes', desc:'CID-10 mais registados no sistema', icone:'🔬' },
          { titulo:'Desempenho por Médico', desc:'Consultas realizadas por cada médico', icone:'👨‍⚕️' },
        ].map(r => (
          <div key={r.titulo} className="card" style={{ cursor:'pointer' }}>
            <div style={{ fontSize:40, marginBottom:12 }}>{r.icone}</div>
            <h3 style={{ fontFamily:'Playfair Display,serif', color:'#0A2540', marginBottom:6 }}>{r.titulo}</h3>
            <p style={{ color:'#5A6A7E', fontSize:13 }}>{r.desc}</p>
            <button className="btn btn-secundario btn-sm" style={{ marginTop:16 }}>Gerar Relatório</button>
          </div>
        ))}
      </div>
    </div>
  );
}
