import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const icones = {
  dashboard: '◈',
  pacientes: '👤',
  consultas: '📅',
  historico: '📋',
  relatorios: '📊',
  sair: '→',
};

export default function Layout() {
  const { usuario, logout } = useAuth();
  const navigate = useNavigate();
  const [colapsado, setColapsado] = useState(false);

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const menus = [
    { path: '/dashboard', label: 'Dashboard', icone: '◈' },
    { path: '/pacientes', label: 'Pacientes', icone: '👤', papeis: ['admin','recepcao','medico'] },
    { path: '/consultas', label: 'Consultas', icone: '📅' },
    { path: '/relatorios', label: 'Relatórios', icone: '📊', papeis: ['admin'] },
  ].filter(m => !m.papeis || m.papeis.includes(usuario?.papel));

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      {/* Sidebar */}
      <aside style={{
        width: colapsado ? 70 : 240,
        background: 'linear-gradient(180deg, #0A2540 0%, #1A3A5C 100%)',
        display: 'flex', flexDirection: 'column',
        transition: 'width 0.3s', overflow: 'hidden', flexShrink: 0,
      }}>
        {/* Logo */}
        <div style={{ padding: '24px 20px', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{
              width: 36, height: 36, borderRadius: 10,
              background: 'linear-gradient(135deg, #00B4D8, #2E86AB)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 18, flexShrink: 0,
            }}>👁</div>
            {!colapsado && (
              <div>
                <div style={{ color: '#fff', fontWeight: 700, fontSize: 15, fontFamily: 'Playfair Display, serif' }}>OftalmoCare</div>
                <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 11 }}>Beira, Moçambique</div>
              </div>
            )}
          </div>
        </div>

        {/* Menus */}
        <nav style={{ flex: 1, padding: '16px 12px', display: 'flex', flexDirection: 'column', gap: 4 }}>
          {menus.map(m => (
            <NavLink key={m.path} to={m.path} style={({ isActive }) => ({
              display: 'flex', alignItems: 'center', gap: 12,
              padding: '10px 12px', borderRadius: 8, textDecoration: 'none',
              color: isActive ? '#fff' : 'rgba(255,255,255,0.6)',
              background: isActive ? 'rgba(46,134,171,0.4)' : 'transparent',
              transition: 'all 0.2s', fontWeight: isActive ? 600 : 400,
              whiteSpace: 'nowrap',
            })}>
              <span style={{ fontSize: 18, flexShrink: 0 }}>{m.icone}</span>
              {!colapsado && <span style={{ fontSize: 14 }}>{m.label}</span>}
            </NavLink>
          ))}
        </nav>

        {/* User + Logout */}
        <div style={{ padding: '16px 12px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
          {!colapsado && (
            <div style={{ marginBottom: 12, padding: '8px 12px', background: 'rgba(255,255,255,0.05)', borderRadius: 8 }}>
              <div style={{ color: '#fff', fontWeight: 600, fontSize: 13 }}>{usuario?.nome}</div>
              <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 12, textTransform: 'capitalize' }}>{usuario?.papel}</div>
            </div>
          )}
          <button onClick={handleLogout} style={{
            display: 'flex', alignItems: 'center', gap: 10,
            width: '100%', padding: '10px 12px', borderRadius: 8,
            border: 'none', background: 'transparent', cursor: 'pointer',
            color: 'rgba(255,255,255,0.6)', fontSize: 14,
          }}>
            <span style={{ fontSize: 18 }}>→</span>
            {!colapsado && 'Sair'}
          </button>
        </div>
      </aside>

      {/* Main */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {/* Topbar */}
        <header style={{
          background: '#fff', padding: '0 24px', height: 60,
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          boxShadow: '0 1px 0 #D6E4F0', flexShrink: 0,
        }}>
          <button onClick={() => setColapsado(!colapsado)} style={{
            background: 'none', border: 'none', fontSize: 20, cursor: 'pointer', color: '#5A6A7E',
          }}>☰</button>
          <div style={{ color: '#5A6A7E', fontSize: 13 }}>
            {new Date().toLocaleDateString('pt-MZ', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
          </div>
        </header>

        {/* Content */}
        <main style={{ flex: 1, overflow: 'auto', padding: 24 }} className="fade-in">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
