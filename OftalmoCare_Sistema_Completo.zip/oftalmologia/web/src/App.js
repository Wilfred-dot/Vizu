import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';

import Login from './pages/Login';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Pacientes from './pages/Pacientes';
import Consultas from './pages/Consultas';
import NovaConsulta from './pages/NovaConsulta';
import HistoricoClinico from './pages/HistoricoClinico';
import Relatorios from './pages/Relatorios';

const Privado = ({ children, papeis }) => {
  const { usuario, carregando } = useAuth();
  if (carregando) return <div style={{display:'flex',justifyContent:'center',alignItems:'center',height:'100vh'}}><div className="spinner"/></div>;
  if (!usuario) return <Navigate to="/login" />;
  if (papeis && !papeis.includes(usuario.papel)) return <Navigate to="/dashboard" />;
  return children;
};

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<Privado><Layout /></Privado>}>
            <Route index element={<Navigate to="/dashboard" />} />
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="pacientes" element={<Privado papeis={['admin','recepcao','medico']}><Pacientes /></Privado>} />
            <Route path="consultas" element={<Consultas />} />
            <Route path="consultas/nova" element={<Privado papeis={['admin','recepcao']}><NovaConsulta /></Privado>} />
            <Route path="historico/:pacienteId" element={<HistoricoClinico />} />
            <Route path="relatorios" element={<Privado papeis={['admin']}><Relatorios /></Privado>} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
