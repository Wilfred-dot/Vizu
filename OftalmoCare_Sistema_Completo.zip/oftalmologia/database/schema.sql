-- =====================================================
-- SISTEMA DE GESTÃO DE SAÚDE OFTALMOLÓGICA
-- Universidade Católica de Moçambique - Beira, 2026
-- Autor: Wilfred Deloviar Júnior
-- =====================================================

-- Extensões
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =====================================================
-- TABELA: users
-- =====================================================
CREATE TABLE users (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nome        VARCHAR(150) NOT NULL,
  email       VARCHAR(150) UNIQUE NOT NULL,
  senha_hash  TEXT NOT NULL,
  papel       VARCHAR(20) NOT NULL CHECK (papel IN ('admin', 'recepcao', 'medico', 'paciente')),
  telefone    VARCHAR(20),
  ativo       BOOLEAN DEFAULT TRUE,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- TABELA: pacientes
-- =====================================================
CREATE TABLE pacientes (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id          UUID REFERENCES users(id) ON DELETE CASCADE,
  num_processo     VARCHAR(20) UNIQUE NOT NULL,
  data_nascimento  DATE NOT NULL,
  genero           VARCHAR(10) CHECK (genero IN ('masculino', 'feminino', 'outro')),
  morada           TEXT,
  bairro           VARCHAR(100),
  cidade           VARCHAR(100) DEFAULT 'Beira',
  bi_numero        VARCHAR(30),
  tipo_sanguineo   VARCHAR(5),
  alergias         TEXT,
  created_at       TIMESTAMPTZ DEFAULT NOW(),
  updated_at       TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- TABELA: medicos
-- =====================================================
CREATE TABLE medicos (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID REFERENCES users(id) ON DELETE CASCADE,
  crm           VARCHAR(30) UNIQUE NOT NULL,
  especialidade VARCHAR(100) DEFAULT 'Oftalmologia',
  horario_inicio TIME DEFAULT '08:00',
  horario_fim    TIME DEFAULT '17:00',
  dias_trabalho  VARCHAR(50) DEFAULT 'seg,ter,qua,qui,sex',
  created_at     TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- TABELA: consultas
-- =====================================================
CREATE TABLE consultas (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  paciente_id       UUID NOT NULL REFERENCES pacientes(id) ON DELETE CASCADE,
  medico_id         UUID NOT NULL REFERENCES medicos(id),
  data_hora         TIMESTAMPTZ NOT NULL,
  status            VARCHAR(20) DEFAULT 'agendada' CHECK (status IN ('agendada','confirmada','em_atendimento','concluida','cancelada','falta')),
  tipo              VARCHAR(50) DEFAULT 'consulta' CHECK (tipo IN ('consulta','retorno','exame','cirurgia','urgencia')),
  motivo            TEXT,
  observacoes_adm   TEXT,
  numero_senha      INT,
  duracao_min       INT DEFAULT 30,
  created_at        TIMESTAMPTZ DEFAULT NOW(),
  updated_at        TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- TABELA: historico_clinico
-- =====================================================
CREATE TABLE historico_clinico (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  paciente_id     UUID NOT NULL REFERENCES pacientes(id) ON DELETE CASCADE,
  medico_id       UUID NOT NULL REFERENCES medicos(id),
  consulta_id     UUID REFERENCES consultas(id),
  data_atendimento TIMESTAMPTZ DEFAULT NOW(),
  -- Anamnese
  queixa_principal TEXT,
  historia_doenca  TEXT,
  -- Oftalmológico
  acuidade_visual_od  VARCHAR(20), -- olho direito
  acuidade_visual_oe  VARCHAR(20), -- olho esquerdo
  pressao_intraocular_od DECIMAL(5,2),
  pressao_intraocular_oe DECIMAL(5,2),
  biomicroscopia      TEXT,
  fundoscopia         TEXT,
  -- Diagnóstico e plano
  diagnostico     TEXT NOT NULL,
  cid10           VARCHAR(10),
  tratamento      TEXT,
  plano_retorno   TEXT,
  observacoes     TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- TABELA: receitas
-- =====================================================
CREATE TABLE receitas (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  historico_id     UUID NOT NULL REFERENCES historico_clinico(id) ON DELETE CASCADE,
  paciente_id      UUID NOT NULL REFERENCES pacientes(id),
  medico_id        UUID NOT NULL REFERENCES medicos(id),
  data_emissao     DATE DEFAULT CURRENT_DATE,
  validade_dias    INT DEFAULT 30,
  observacoes      TEXT,
  created_at       TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- TABELA: itens_receita
-- =====================================================
CREATE TABLE itens_receita (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  receita_id    UUID NOT NULL REFERENCES receitas(id) ON DELETE CASCADE,
  medicamento   VARCHAR(200) NOT NULL,
  concentracao  VARCHAR(50),
  forma         VARCHAR(50),  -- colírio, comprimido, pomada
  dose          VARCHAR(100),
  frequencia    VARCHAR(100),
  duracao       VARCHAR(100),
  instrucoes    TEXT
);

-- =====================================================
-- TABELA: exames
-- =====================================================
CREATE TABLE exames (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  paciente_id   UUID NOT NULL REFERENCES pacientes(id),
  medico_id     UUID NOT NULL REFERENCES medicos(id),
  consulta_id   UUID REFERENCES consultas(id),
  tipo_exame    VARCHAR(100) NOT NULL,
  data_pedido   TIMESTAMPTZ DEFAULT NOW(),
  data_resultado TIMESTAMPTZ,
  resultado     TEXT,
  arquivo_url   TEXT,
  status        VARCHAR(20) DEFAULT 'pendente' CHECK (status IN ('pendente','em_processamento','concluido')),
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- TABELA: notificacoes
-- =====================================================
CREATE TABLE notificacoes (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  titulo      VARCHAR(200) NOT NULL,
  mensagem    TEXT NOT NULL,
  tipo        VARCHAR(30) DEFAULT 'info' CHECK (tipo IN ('info','lembrete','urgente','sistema')),
  lida        BOOLEAN DEFAULT FALSE,
  data_envio  TIMESTAMPTZ DEFAULT NOW(),
  consulta_id UUID REFERENCES consultas(id)
);

-- =====================================================
-- TABELA: refresh_tokens
-- =====================================================
CREATE TABLE refresh_tokens (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token       TEXT NOT NULL,
  expires_at  TIMESTAMPTZ NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- ÍNDICES
-- =====================================================
CREATE INDEX idx_consultas_paciente    ON consultas(paciente_id);
CREATE INDEX idx_consultas_medico      ON consultas(medico_id);
CREATE INDEX idx_consultas_data        ON consultas(data_hora);
CREATE INDEX idx_consultas_status      ON consultas(status);
CREATE INDEX idx_historico_paciente    ON historico_clinico(paciente_id);
CREATE INDEX idx_notificacoes_user     ON notificacoes(user_id, lida);
CREATE INDEX idx_pacientes_processo    ON pacientes(num_processo);

-- =====================================================
-- FUNÇÃO: auto atualizar updated_at
-- =====================================================
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated     BEFORE UPDATE ON users     FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_pacientes_updated BEFORE UPDATE ON pacientes FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_consultas_updated BEFORE UPDATE ON consultas FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- =====================================================
-- DADOS INICIAIS (SEED)
-- =====================================================

-- Admin padrão (senha: admin123)
INSERT INTO users (nome, email, senha_hash, papel) VALUES
  ('Administrador', 'admin@oftalmologia.mz', crypt('admin123', gen_salt('bf')), 'admin');

-- Médico exemplo
INSERT INTO users (nome, email, senha_hash, papel, telefone) VALUES
  ('Dr. João Henriques', 'joao.henriques@oftalmologia.mz', crypt('medico123', gen_salt('bf')), 'medico', '+258 84 000 0001');

INSERT INTO medicos (user_id, crm, especialidade)
SELECT id, 'CRM-MOZ-0001', 'Oftalmologia' FROM users WHERE email = 'joao.henriques@oftalmologia.mz';

-- Recepcionista
INSERT INTO users (nome, email, senha_hash, papel, telefone) VALUES
  ('Ana Machava', 'ana.machava@oftalmologia.mz', crypt('recepcao123', gen_salt('bf')), 'recepcao', '+258 84 000 0002');

-- Paciente exemplo
INSERT INTO users (nome, email, senha_hash, papel, telefone) VALUES
  ('Maria Fernanda', 'maria.fernanda@gmail.com', crypt('paciente123', gen_salt('bf')), 'paciente', '+258 84 111 2233');

INSERT INTO pacientes (user_id, num_processo, data_nascimento, genero, morada, bairro)
SELECT id, 'P-2026-001', '1985-06-15', 'feminino', 'Rua da Beira, nº 10', 'Chaimite'
FROM users WHERE email = 'maria.fernanda@gmail.com';
