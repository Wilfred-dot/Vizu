// src/theme.js
export const cores = {
  azulProfundo: '#0A2540',
  azulMedio: '#1A5276',
  azulClaro: '#2E86AB',
  ciano: '#00B4D8',
  verde: '#00C49A',
  vermelho: '#E63946',
  amarelo: '#F4A261',
  bg: '#F0F4F8',
  bgCard: '#FFFFFF',
  texto: '#1A1A2E',
  textoSub: '#5A6A7E',
  borda: '#D6E4F0',
};

export const sombra = {
  shadowColor: '#0A2540',
  shadowOffset: { width: 0, height: 2 },
  shadowOpacity: 0.08,
  shadowRadius: 8,
  elevation: 3,
};
