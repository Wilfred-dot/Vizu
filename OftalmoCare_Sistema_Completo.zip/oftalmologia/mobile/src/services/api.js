import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Altere para o IP do seu servidor
const BASE_URL = 'http://192.168.1.100:3001/api';

const api = axios.create({ baseURL: BASE_URL });

api.interceptors.request.use(async config => {
  const token = await AsyncStorage.getItem('accessToken');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  res => res,
  async error => {
    if (error.response?.status === 403) {
      const refresh = await AsyncStorage.getItem('refreshToken');
      if (refresh) {
        try {
          const { data } = await axios.post(`${BASE_URL}/auth/refresh`, { refreshToken: refresh });
          await AsyncStorage.setItem('accessToken', data.accessToken);
          error.config.headers.Authorization = `Bearer ${data.accessToken}`;
          return api.request(error.config);
        } catch {
          await AsyncStorage.multiRemove(['accessToken', 'refreshToken', 'usuario']);
        }
      }
    }
    return Promise.reject(error);
  }
);

export default api;
