import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import api from '../services/api';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [usuario, setUsuario] = useState(null);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    AsyncStorage.getItem('usuario').then(u => {
      if (u) setUsuario(JSON.parse(u));
      setCarregando(false);
    });
  }, []);

  const login = async (email, senha) => {
    const { data } = await api.post('/auth/login', { email, senha });
    await AsyncStorage.multiSet([
      ['accessToken', data.accessToken],
      ['refreshToken', data.refreshToken],
      ['usuario', JSON.stringify(data.usuario)],
    ]);
    setUsuario(data.usuario);
    return data.usuario;
  };

  const logout = async () => {
    const refresh = await AsyncStorage.getItem('refreshToken');
    try { await api.post('/auth/logout', { refreshToken: refresh }); } catch {}
    await AsyncStorage.multiRemove(['accessToken', 'refreshToken', 'usuario']);
    setUsuario(null);
  };

  return (
    <AuthContext.Provider value={{ usuario, login, logout, carregando }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
