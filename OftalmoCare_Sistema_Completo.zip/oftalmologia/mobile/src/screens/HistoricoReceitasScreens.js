import React, { useState, useEffect } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  ActivityIndicator, RefreshControl,
} from 'react-native';
import { useAuth } from '../context/AuthContext';
import { cores, sombra } from '../theme';
import api from '../services/api';

export function HistoricoScreen() {
  const { usuario } = useAuth();
  const [historico, setHistorico] = useState([]);
  const [pacienteId, setPacienteId] = useState(null);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    // Buscar ID do paciente pelo user_id
    api.get('/pacientes?limite=1').then(r => {
      // Para paciente logado, a lista virá filtrada automaticamente
      if (r.data.dados?.length) {
        const pid = r.data.dados[0].id;
        setPacienteId(pid);
        return api.get(`/historico/paciente/${pid}`);
      }
    }).then(h => {
      if (h) setHistorico(h.data);
    }).finally(() => setCarregando(false));
  }, []);

  if (carregando) return <View style={s.center}><ActivityIndicator size="large" color={cores.azulClaro} /></View>;

  return (
    <ScrollView style={s.container}>
      <View style={s.headerBand}>
        <Text style={s.titulo}>Histórico Clínico</Text>
        <Text style={s.sub}>{historico.length} consulta(s) registada(s)</Text>
      </View>

      <View style={{ padding: 20 }}>
        {historico.length === 0 ? (
          <View style={[s.card, { alignItems: 'center', padding: 40 }]}>
            <Text style={{ fontSize: 40 }}>📋</Text>
            <Text style={{ color: cores.textoSub, marginTop: 8 }}>Nenhum histórico disponível</Text>
          </View>
        ) : historico.map(h => (
          <View key={h.id} style={s.card}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 }}>
              <Text style={{ color: cores.textoSub, fontSize: 12 }}>
                {new Date(h.data_atendimento).toLocaleDateString('pt-MZ')}
              </Text>
              {h.cid10 && (
                <View style={{ backgroundColor: '#F0F4F8', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6 }}>
                  <Text style={{ fontSize: 11, color: cores.azulMedio, fontWeight: '600' }}>{h.cid10}</Text>
                </View>
              )}
            </View>
            <Text style={s.cardTitulo}>{h.diagnostico}</Text>
            <Text style={{ fontSize: 12, color: cores.textoSub, marginTop: 2 }}>Dr. {h.medico_nome}</Text>
            {h.queixa_principal && (
              <Text style={{ fontSize: 13, color: cores.texto, marginTop: 8 }}>
                <Text style={{ fontWeight: '600' }}>Queixa: </Text>{h.queixa_principal}
              </Text>
            )}
            {(h.acuidade_visual_od || h.acuidade_visual_oe) && (
              <View style={{ flexDirection: 'row', gap: 8, marginTop: 10 }}>
                {h.acuidade_visual_od && (
                  <View style={s.avBox}>
                    <Text style={s.avLabel}>AV OD</Text>
                    <Text style={s.avValor}>{h.acuidade_visual_od}</Text>
                  </View>
                )}
                {h.acuidade_visual_oe && (
                  <View style={s.avBox}>
                    <Text style={s.avLabel}>AV OE</Text>
                    <Text style={s.avValor}>{h.acuidade_visual_oe}</Text>
                  </View>
                )}
              </View>
            )}
            {h.tratamento && (
              <Text style={{ fontSize: 13, color: cores.texto, marginTop: 8 }}>
                <Text style={{ fontWeight: '600' }}>Tratamento: </Text>{h.tratamento}
              </Text>
            )}
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

export function ReceitasScreen() {
  const [receitas, setReceitas] = useState([]);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    api.get('/pacientes?limite=1').then(r => {
      if (r.data.dados?.length) {
        return api.get(`/receitas/paciente/${r.data.dados[0].id}`);
      }
    }).then(r => {
      if (r) setReceitas(r.data);
    }).finally(() => setCarregando(false));
  }, []);

  if (carregando) return <View style={s.center}><ActivityIndicator size="large" color={cores.azulClaro} /></View>;

  return (
    <ScrollView style={s.container}>
      <View style={s.headerBand}>
        <Text style={s.titulo}>Receitas Médicas</Text>
        <Text style={s.sub}>{receitas.length} receita(s) disponível(is)</Text>
      </View>

      <View style={{ padding: 20 }}>
        {receitas.length === 0 ? (
          <View style={[s.card, { alignItems: 'center', padding: 40 }]}>
            <Text style={{ fontSize: 40 }}>💊</Text>
            <Text style={{ color: cores.textoSub, marginTop: 8 }}>Nenhuma receita disponível</Text>
          </View>
        ) : receitas.map(r => (
          <View key={r.id} style={s.card}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 }}>
              <Text style={s.cardTitulo}>Receita Médica</Text>
              <Text style={{ color: cores.textoSub, fontSize: 12 }}>
                {new Date(r.data_emissao).toLocaleDateString('pt-MZ')}
              </Text>
            </View>
            <Text style={{ fontSize: 12, color: cores.azulMedio, marginBottom: 12 }}>Dr. {r.medico_nome}</Text>

            <View style={{ backgroundColor: '#F0F4F8', borderRadius: 10, padding: 12 }}>
              {(r.itens || []).filter(i => i.medicamento).map((item, idx) => (
                <View key={idx} style={{ paddingVertical: 8, borderBottomWidth: idx < r.itens.length-1 ? 1 : 0, borderBottomColor: cores.borda }}>
                  <Text style={{ fontWeight: '700', color: cores.texto, fontSize: 14 }}>{item.medicamento}</Text>
                  {item.dose && <Text style={{ color: cores.textoSub, fontSize: 13 }}>Dose: {item.dose}</Text>}
                  {item.frequencia && <Text style={{ color: cores.textoSub, fontSize: 13 }}>Frequência: {item.frequencia}</Text>}
                  {item.duracao && <Text style={{ color: cores.textoSub, fontSize: 13 }}>Duração: {item.duracao}</Text>}
                  {item.instrucoes && <Text style={{ color: cores.azulMedio, fontSize: 12, marginTop: 4 }}>ℹ️ {item.instrucoes}</Text>}
                </View>
              ))}
            </View>

            <Text style={{ color: cores.textoSub, fontSize: 12, marginTop: 8 }}>
              Válida por {r.validade_dias} dias
            </Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: cores.bg },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  headerBand: {
    backgroundColor: cores.azulProfundo, padding: 24, paddingTop: 52,
  },
  titulo: { fontSize: 24, fontWeight: '700', color: '#fff' },
  sub: { color: 'rgba(255,255,255,0.6)', fontSize: 13, marginTop: 4 },
  card: {
    backgroundColor: '#fff', borderRadius: 12, padding: 16,
    marginBottom: 12, ...sombra,
  },
  cardTitulo: { fontSize: 16, fontWeight: '700', color: cores.texto },
  avBox: { flex: 1, backgroundColor: '#EFF6FF', borderRadius: 8, padding: 10, alignItems: 'center' },
  avLabel: { fontSize: 11, color: cores.textoSub, fontWeight: '600' },
  avValor: { fontSize: 16, fontWeight: '700', color: cores.azulProfundo, marginTop: 2 },
});
