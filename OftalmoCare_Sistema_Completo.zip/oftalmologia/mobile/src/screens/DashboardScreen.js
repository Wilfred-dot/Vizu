import React, { useState, useEffect } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  RefreshControl, ActivityIndicator,
} from 'react-native';
import { useAuth } from '../context/AuthContext';
import { cores, sombra } from '../theme';
import api from '../services/api';

const BadgeStatus = ({ status }) => {
  const cores_badge = {
    agendada: { bg: '#DBEAFE', texto: '#1D4ED8' },
    confirmada: { bg: '#DCFCE7', texto: '#15803D' },
    em_atendimento: { bg: '#FEF3C7', texto: '#B45309' },
    concluida: { bg: '#F0FDF4', texto: '#166534' },
    cancelada: { bg: '#FEE2E2', texto: '#991B1B' },
  };
  const c = cores_badge[status] || { bg: '#F3F4F6', texto: '#374151' };
  return (
    <View style={{ backgroundColor: c.bg, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 20 }}>
      <Text style={{ color: c.texto, fontSize: 11, fontWeight: '600', textTransform: 'capitalize' }}>
        {status?.replace('_', ' ')}
      </Text>
    </View>
  );
};

export default function DashboardScreen({ navigation }) {
  const { usuario, logout } = useAuth();
  const [consultas, setConsultas] = useState([]);
  const [notificacoes, setNotificacoes] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [atualizando, setAtualizando] = useState(false);

  const isPaciente = usuario?.papel === 'paciente';

  const carregar = async () => {
    try {
      const hoje = new Date().toISOString().split('T')[0];
      const [c, n] = await Promise.all([
        api.get(`/consultas?data=${hoje}&limite=10`),
        api.get('/notificacoes'),
      ]);
      setConsultas(c.data);
      setNotificacoes(n.data.filter(n => !n.lida).slice(0, 5));
    } catch {}
    finally {
      setCarregando(false);
      setAtualizando(false);
    }
  };

  useEffect(() => { carregar(); }, []);

  if (carregando) {
    return <View style={s.center}><ActivityIndicator size="large" color={cores.azulClaro} /></View>;
  }

  return (
    <ScrollView
      style={s.container}
      refreshControl={<RefreshControl refreshing={atualizando} onRefresh={() => { setAtualizando(true); carregar(); }} />}
    >
      {/* Header */}
      <View style={s.header}>
        <View>
          <Text style={s.saudacao}>Olá, {usuario?.nome?.split(' ')[0]} 👋</Text>
          <Text style={s.sub}>{new Date().toLocaleDateString('pt-MZ', { weekday: 'long', day: 'numeric', month: 'long' })}</Text>
        </View>
        <TouchableOpacity onPress={logout} style={s.sairBtn}>
          <Text style={s.sairTexto}>→</Text>
        </TouchableOpacity>
      </View>

      {/* Notificações */}
      {notificacoes.length > 0 && (
        <View style={s.section}>
          <Text style={s.sectionTitulo}>🔔 Notificações</Text>
          {notificacoes.map(n => (
            <View key={n.id} style={[s.card, { borderLeftWidth: 3, borderLeftColor: cores.ciano }]}>
              <Text style={s.cardTitulo}>{n.titulo}</Text>
              <Text style={s.cardTexto}>{n.mensagem}</Text>
              <Text style={{ color: cores.textoSub, fontSize: 11, marginTop: 4 }}>
                {new Date(n.data_envio).toLocaleDateString('pt-MZ')}
              </Text>
            </View>
          ))}
        </View>
      )}

      {/* Consultas */}
      <View style={s.section}>
        <View style={s.sectionHeader}>
          <Text style={s.sectionTitulo}>📅 Consultas de Hoje</Text>
          {!isPaciente && (
            <TouchableOpacity onPress={() => navigation.navigate('NovaConsulta')}>
              <Text style={{ color: cores.azulClaro, fontWeight: '600', fontSize: 14 }}>+ Agendar</Text>
            </TouchableOpacity>
          )}
        </View>

        {consultas.length === 0 ? (
          <View style={[s.card, { alignItems: 'center', padding: 32 }]}>
            <Text style={{ fontSize: 36 }}>📭</Text>
            <Text style={{ color: cores.textoSub, marginTop: 8 }}>Nenhuma consulta hoje</Text>
          </View>
        ) : consultas.map(c => (
          <View key={c.id} style={s.card}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 20, fontWeight: '800', color: cores.azulProfundo }}>#{c.numero_senha}</Text>
                <Text style={s.cardTitulo}>{c.paciente_nome}</Text>
                <Text style={s.cardTexto}>Dr. {c.medico_nome}</Text>
                <Text style={{ color: cores.azulClaro, fontSize: 13, marginTop: 2 }}>
                  🕐 {new Date(c.data_hora).toLocaleTimeString('pt-MZ', { hour: '2-digit', minute: '2-digit' })}
                </Text>
              </View>
              <BadgeStatus status={c.status} />
            </View>
          </View>
        ))}
      </View>

      {/* Ações rápidas */}
      <View style={s.section}>
        <Text style={s.sectionTitulo}>Acesso Rápido</Text>
        <View style={{ flexDirection: 'row', gap: 12 }}>
          {[
            { label: 'Consultas', icone: '📅', tela: 'Consultas' },
            { label: 'Receitas', icone: '💊', tela: 'Receitas' },
            { label: 'Histórico', icone: '📋', tela: 'Historico' },
          ].map(a => (
            <TouchableOpacity key={a.label} style={s.acaoCard}
              onPress={() => navigation.navigate(a.tela)}>
              <Text style={{ fontSize: 28 }}>{a.icone}</Text>
              <Text style={{ fontSize: 12, color: cores.texto, fontWeight: '600', marginTop: 6 }}>{a.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: cores.bg },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: {
    backgroundColor: cores.azulProfundo, padding: 24, paddingTop: 56,
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
  },
  saudacao: { fontSize: 22, fontWeight: '700', color: '#fff' },
  sub: { color: 'rgba(255,255,255,0.6)', fontSize: 13, marginTop: 2 },
  sairBtn: { padding: 8 },
  sairTexto: { fontSize: 20, color: 'rgba(255,255,255,0.7)' },
  section: { padding: 20 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  sectionTitulo: { fontSize: 17, fontWeight: '700', color: cores.azulProfundo, marginBottom: 12 },
  card: {
    backgroundColor: '#fff', borderRadius: 12, padding: 16,
    marginBottom: 10, ...sombra,
  },
  cardTitulo: { fontSize: 15, fontWeight: '600', color: cores.texto, marginBottom: 2 },
  cardTexto: { fontSize: 13, color: cores.textoSub },
  acaoCard: {
    flex: 1, backgroundColor: '#fff', borderRadius: 12, padding: 16,
    alignItems: 'center', ...sombra,
  },
});
