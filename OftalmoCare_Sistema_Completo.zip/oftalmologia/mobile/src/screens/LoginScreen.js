import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, ActivityIndicator, Alert, ScrollView,
} from 'react-native';
import { useAuth } from '../context/AuthContext';
import { cores } from '../theme';

export default function LoginScreen({ navigation }) {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [carregando, setCarregando] = useState(false);

  const handleLogin = async () => {
    if (!email || !senha) return Alert.alert('Erro', 'Preencha email e senha');
    setCarregando(true);
    try {
      await login(email.trim().toLowerCase(), senha);
    } catch (err) {
      Alert.alert('Erro de Autenticação', err.response?.data?.erro || 'Não foi possível entrar');
    } finally {
      setCarregando(false);
    }
  };

  return (
    <KeyboardAvoidingView style={s.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={s.inner} keyboardShouldPersistTaps="handled">
        {/* Header */}
        <View style={s.header}>
          <View style={s.logoBox}>
            <Text style={s.logoEmoji}>👁</Text>
          </View>
          <Text style={s.titulo}>OftalmoCare</Text>
          <Text style={s.subtitulo}>Sistema de Saúde Oftalmológica{'\n'}Beira, Moçambique</Text>
        </View>

        {/* Card */}
        <View style={s.card}>
          <Text style={s.cardTitulo}>Entrar na sua conta</Text>

          <Text style={s.label}>Email</Text>
          <TextInput
            style={s.input}
            value={email}
            onChangeText={setEmail}
            placeholder="seu@email.com"
            keyboardType="email-address"
            autoCapitalize="none"
            placeholderTextColor={cores.textoSub}
          />

          <Text style={s.label}>Senha</Text>
          <TextInput
            style={s.input}
            value={senha}
            onChangeText={setSenha}
            placeholder="••••••••"
            secureTextEntry
            placeholderTextColor={cores.textoSub}
          />

          <TouchableOpacity style={s.botao} onPress={handleLogin} disabled={carregando}>
            {carregando
              ? <ActivityIndicator color="#fff" />
              : <Text style={s.botaoTexto}>Entrar</Text>}
          </TouchableOpacity>
        </View>

        <Text style={s.rodape}>
          Clínica Oftalmológica da Beira{'\n'}© 2026 – UCM Tecnologias de Informação
        </Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: cores.azulProfundo },
  inner: { flexGrow: 1, justifyContent: 'center', padding: 24 },
  header: { alignItems: 'center', marginBottom: 32 },
  logoBox: {
    width: 80, height: 80, borderRadius: 24,
    backgroundColor: 'rgba(255,255,255,0.15)',
    justifyContent: 'center', alignItems: 'center', marginBottom: 16,
  },
  logoEmoji: { fontSize: 40 },
  titulo: { fontSize: 32, fontWeight: '700', color: '#fff', marginBottom: 8 },
  subtitulo: { fontSize: 14, color: 'rgba(255,255,255,0.6)', textAlign: 'center', lineHeight: 20 },
  card: {
    backgroundColor: '#fff', borderRadius: 20, padding: 28,
    shadowColor: '#000', shadowOpacity: 0.2, shadowRadius: 20, elevation: 8,
  },
  cardTitulo: { fontSize: 18, fontWeight: '700', color: cores.azulProfundo, marginBottom: 20 },
  label: { fontSize: 13, fontWeight: '600', color: cores.textoSub, marginBottom: 6 },
  input: {
    borderWidth: 1.5, borderColor: cores.borda, borderRadius: 10,
    padding: 12, fontSize: 15, color: cores.texto, marginBottom: 16,
  },
  botao: {
    backgroundColor: cores.azulClaro, borderRadius: 10,
    padding: 14, alignItems: 'center', marginTop: 4,
  },
  botaoTexto: { color: '#fff', fontSize: 16, fontWeight: '700' },
  rodape: { textAlign: 'center', color: 'rgba(255,255,255,0.4)', fontSize: 12, marginTop: 24, lineHeight: 18 },
});
