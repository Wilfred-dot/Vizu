import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Text } from 'react-native';
import { AuthProvider, useAuth } from './src/context/AuthContext';
import { cores } from './src/theme';

import LoginScreen from './src/screens/LoginScreen';
import DashboardScreen from './src/screens/DashboardScreen';
import { HistoricoScreen, ReceitasScreen } from './src/screens/HistoricoReceitasScreens';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

function TabsNav() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused }) => {
          const icones = { Dashboard: '◈', Historico: '📋', Receitas: '💊', Consultas: '📅' };
          return <Text style={{ fontSize: 22, opacity: focused ? 1 : 0.5 }}>{icones[route.name]}</Text>;
        },
        tabBarActiveTintColor: cores.azulClaro,
        tabBarInactiveTintColor: cores.textoSub,
        tabBarStyle: {
          backgroundColor: '#fff',
          borderTopColor: cores.borda,
          height: 60, paddingBottom: 8,
        },
        headerShown: false,
        tabBarLabelStyle: { fontSize: 11, fontWeight: '600' },
      })}
    >
      <Tab.Screen name="Dashboard" component={DashboardScreen} options={{ title: 'Início' }} />
      <Tab.Screen name="Historico" component={HistoricoScreen} options={{ title: 'Histórico' }} />
      <Tab.Screen name="Receitas" component={ReceitasScreen} options={{ title: 'Receitas' }} />
    </Tab.Navigator>
  );
}

function RootNav() {
  const { usuario, carregando } = useAuth();
  if (carregando) return null;

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      {!usuario ? (
        <Stack.Screen name="Login" component={LoginScreen} />
      ) : (
        <Stack.Screen name="Home" component={TabsNav} />
      )}
    </Stack.Navigator>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <NavigationContainer>
        <RootNav />
      </NavigationContainer>
    </AuthProvider>
  );
}
