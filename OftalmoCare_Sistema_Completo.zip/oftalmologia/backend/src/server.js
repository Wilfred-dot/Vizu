require('dotenv').config();
const express = require('express');
const cors = require('cors');

const authRoutes       = require('./routes/auth');
const pacientesRoutes  = require('./routes/pacientes');
const consultasRoutes  = require('./routes/consultas');
const medicosRoutes    = require('./routes/medicos');
const historicoRoutes  = require('./routes/historico');
const receitasRoutes   = require('./routes/receitas');
const notificacoesRoutes = require('./routes/notificacoes');
const dashboardRoutes  = require('./routes/dashboard');

const app = express();

app.use(cors());
app.use(express.json());

// Rotas
app.use('/api/auth',          authRoutes);
app.use('/api/pacientes',     pacientesRoutes);
app.use('/api/consultas',     consultasRoutes);
app.use('/api/medicos',       medicosRoutes);
app.use('/api/historico',     historicoRoutes);
app.use('/api/receitas',      receitasRoutes);
app.use('/api/notificacoes',  notificacoesRoutes);
app.use('/api/dashboard',     dashboardRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', sistema: 'Oftalmologia API', versao: '1.0.0' });
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ erro: 'Erro interno do servidor' });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`🏥 Servidor rodando na porta ${PORT}`);
});
