const router = require('express').Router();
const db = require('../db');
const { autenticar } = require('../middleware/auth');

router.get('/', autenticar, async (req, res) => {
  try {
    const { rows } = await db.query(
      'SELECT * FROM notificacoes WHERE user_id=$1 ORDER BY data_envio DESC LIMIT 50',
      [req.usuario.id]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ erro: 'Erro interno' });
  }
});

router.patch('/:id/lida', autenticar, async (req, res) => {
  try {
    await db.query('UPDATE notificacoes SET lida=TRUE WHERE id=$1 AND user_id=$2', [req.params.id, req.usuario.id]);
    res.json({ mensagem: 'Marcada como lida' });
  } catch (err) {
    res.status(500).json({ erro: 'Erro interno' });
  }
});

router.patch('/todas/lidas', autenticar, async (req, res) => {
  try {
    await db.query('UPDATE notificacoes SET lida=TRUE WHERE user_id=$1', [req.usuario.id]);
    res.json({ mensagem: 'Todas marcadas como lidas' });
  } catch (err) {
    res.status(500).json({ erro: 'Erro interno' });
  }
});

module.exports = router;
