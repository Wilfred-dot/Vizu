const router = require('express').Router();
const db = require('../db');
const { autenticar, autorizar } = require('../middleware/auth');

// GET receitas do paciente
router.get('/paciente/:pacienteId', autenticar, async (req, res) => {
  try {
    const { rows } = await db.query(`
      SELECT r.*, um.nome AS medico_nome,
             json_agg(json_build_object('medicamento',i.medicamento,'dose',i.dose,'frequencia',i.frequencia,'duracao',i.duracao,'instrucoes',i.instrucoes)) AS itens
      FROM receitas r
      JOIN medicos m ON r.medico_id=m.id JOIN users um ON m.user_id=um.id
      LEFT JOIN itens_receita i ON i.receita_id=r.id
      WHERE r.paciente_id=$1
      GROUP BY r.id, um.nome
      ORDER BY r.data_emissao DESC
    `, [req.params.pacienteId]);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ erro: 'Erro interno' });
  }
});

// POST criar receita
router.post('/', autenticar, autorizar('medico'), async (req, res) => {
  const { historico_id, paciente_id, observacoes, itens, validade_dias } = req.body;
  if (!historico_id || !paciente_id || !itens?.length) {
    return res.status(400).json({ erro: 'historico_id, paciente_id e itens são obrigatórios' });
  }

  try {
    const { rows: med } = await db.query('SELECT id FROM medicos WHERE user_id=$1', [req.usuario.id]);
    if (!med.length) return res.status(403).json({ erro: 'Acesso negado' });

    await db.query('BEGIN');
    const { rows: recRows } = await db.query(
      'INSERT INTO receitas (historico_id, paciente_id, medico_id, observacoes, validade_dias) VALUES ($1,$2,$3,$4,$5) RETURNING *',
      [historico_id, paciente_id, med[0].id, observacoes, validade_dias || 30]
    );
    const receitaId = recRows[0].id;

    for (const item of itens) {
      await db.query(
        'INSERT INTO itens_receita (receita_id, medicamento, concentracao, forma, dose, frequencia, duracao, instrucoes) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)',
        [receitaId, item.medicamento, item.concentracao, item.forma, item.dose, item.frequencia, item.duracao, item.instrucoes]
      );
    }

    // Notificar paciente
    const { rows: pacUser } = await db.query('SELECT user_id FROM pacientes WHERE id=$1', [paciente_id]);
    if (pacUser.length) {
      await db.query(
        'INSERT INTO notificacoes (user_id, titulo, mensagem, tipo) VALUES ($1,$2,$3,$4)',
        [pacUser[0].user_id, 'Nova Receita Disponível', 'O seu médico emitiu uma nova receita. Consulte o histórico clínico.', 'info']
      );
    }

    await db.query('COMMIT');
    res.status(201).json({ ...recRows[0], itens });
  } catch (err) {
    await db.query('ROLLBACK');
    console.error(err);
    res.status(500).json({ erro: 'Erro ao criar receita' });
  }
});

module.exports = router;
