// historico.js
const router = require('express').Router();
const db = require('../db');
const { autenticar, autorizar } = require('../middleware/auth');

router.get('/paciente/:pacienteId', autenticar, async (req, res) => {
  try {
    const { rows } = await db.query(`
      SELECT h.*, um.nome AS medico_nome, m.crm
      FROM historico_clinico h
      JOIN medicos m ON h.medico_id=m.id JOIN users um ON m.user_id=um.id
      WHERE h.paciente_id=$1 ORDER BY h.data_atendimento DESC
    `, [req.params.pacienteId]);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ erro: 'Erro interno' });
  }
});

router.post('/', autenticar, autorizar('medico'), async (req, res) => {
  const { paciente_id, consulta_id, queixa_principal, historia_doenca,
          acuidade_visual_od, acuidade_visual_oe, pressao_intraocular_od, pressao_intraocular_oe,
          biomicroscopia, fundoscopia, diagnostico, cid10, tratamento, plano_retorno, observacoes } = req.body;

  if (!paciente_id || !diagnostico) return res.status(400).json({ erro: 'paciente_id e diagnóstico obrigatórios' });

  try {
    const { rows: med } = await db.query('SELECT id FROM medicos WHERE user_id=$1', [req.usuario.id]);
    if (!med.length) return res.status(403).json({ erro: 'Apenas médicos podem criar histórico' });

    const { rows } = await db.query(`
      INSERT INTO historico_clinico 
        (paciente_id, medico_id, consulta_id, queixa_principal, historia_doenca,
         acuidade_visual_od, acuidade_visual_oe, pressao_intraocular_od, pressao_intraocular_oe,
         biomicroscopia, fundoscopia, diagnostico, cid10, tratamento, plano_retorno, observacoes)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16) RETURNING *`,
      [paciente_id, med[0].id, consulta_id, queixa_principal, historia_doenca,
       acuidade_visual_od, acuidade_visual_oe, pressao_intraocular_od, pressao_intraocular_oe,
       biomicroscopia, fundoscopia, diagnostico, cid10, tratamento, plano_retorno, observacoes]
    );

    if (consulta_id) {
      await db.query('UPDATE consultas SET status=\'concluida\', updated_at=NOW() WHERE id=$1', [consulta_id]);
    }

    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro ao guardar histórico' });
  }
});

module.exports = router;
