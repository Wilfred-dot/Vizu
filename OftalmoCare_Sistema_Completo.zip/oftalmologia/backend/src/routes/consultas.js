const router = require('express').Router();
const db = require('../db');
const { autenticar, autorizar } = require('../middleware/auth');

// GET /api/consultas
router.get('/', autenticar, async (req, res) => {
  const { data, status, medico_id, paciente_id, pagina = 1, limite = 30 } = req.query;
  const offset = (pagina - 1) * limite;
  const params = [];
  let where = 'WHERE 1=1';

  if (data) {
    params.push(data);
    where += ` AND DATE(c.data_hora) = $${params.length}`;
  }
  if (status) {
    params.push(status);
    where += ` AND c.status = $${params.length}`;
  }
  if (medico_id) {
    params.push(medico_id);
    where += ` AND c.medico_id = $${params.length}`;
  }
  if (paciente_id) {
    params.push(paciente_id);
    where += ` AND c.paciente_id = $${params.length}`;
  }

  // Pacientes só vêem as suas consultas
  if (req.usuario.papel === 'paciente') {
    const { rows: pac } = await db.query('SELECT id FROM pacientes WHERE user_id=$1', [req.usuario.id]);
    if (pac.length) {
      params.push(pac[0].id);
      where += ` AND c.paciente_id = $${params.length}`;
    }
  }

  params.push(limite, offset);
  try {
    const { rows } = await db.query(`
      SELECT c.*,
             up.nome AS paciente_nome, p.num_processo,
             um.nome AS medico_nome, m.especialidade
      FROM consultas c
      JOIN pacientes p ON c.paciente_id = p.id
      JOIN users up    ON p.user_id = up.id
      JOIN medicos m   ON c.medico_id = m.id
      JOIN users um    ON m.user_id = um.id
      ${where}
      ORDER BY c.data_hora ASC
      LIMIT $${params.length-1} OFFSET $${params.length}
    `, params);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro ao buscar consultas' });
  }
});

// GET /api/consultas/:id
router.get('/:id', autenticar, async (req, res) => {
  try {
    const { rows } = await db.query(`
      SELECT c.*, up.nome AS paciente_nome, p.num_processo,
             um.nome AS medico_nome, m.crm, m.especialidade
      FROM consultas c
      JOIN pacientes p ON c.paciente_id = p.id JOIN users up ON p.user_id = up.id
      JOIN medicos m ON c.medico_id = m.id JOIN users um ON m.user_id = um.id
      WHERE c.id=$1`, [req.params.id]);
    if (!rows.length) return res.status(404).json({ erro: 'Consulta não encontrada' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ erro: 'Erro interno' });
  }
});

// POST /api/consultas
router.post('/', autenticar, autorizar('admin','recepcao','paciente'), async (req, res) => {
  const { paciente_id, medico_id, data_hora, tipo, motivo, observacoes_adm } = req.body;
  if (!paciente_id || !medico_id || !data_hora) {
    return res.status(400).json({ erro: 'paciente_id, medico_id e data_hora são obrigatórios' });
  }

  try {
    // Verificar conflito de horário
    const conflito = await db.query(
      `SELECT id FROM consultas WHERE medico_id=$1 AND data_hora=$2 AND status NOT IN ('cancelada','falta')`,
      [medico_id, data_hora]
    );
    if (conflito.rows.length) return res.status(409).json({ erro: 'Médico já tem consulta neste horário' });

    // Gerar número de senha
    const { rows: senhaCont } = await db.query(
      `SELECT COUNT(*)+1 AS prox FROM consultas WHERE DATE(data_hora)=$1`,
      [data_hora.split('T')[0]]
    );
    const senha = parseInt(senhaCont[0].prox);

    const { rows } = await db.query(
      `INSERT INTO consultas (paciente_id, medico_id, data_hora, tipo, motivo, observacoes_adm, numero_senha)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [paciente_id, medico_id, data_hora, tipo || 'consulta', motivo, observacoes_adm, senha]
    );

    // Notificar paciente
    const { rows: pacUser } = await db.query('SELECT user_id FROM pacientes WHERE id=$1', [paciente_id]);
    if (pacUser.length) {
      await db.query(
        `INSERT INTO notificacoes (user_id, titulo, mensagem, tipo, consulta_id)
         VALUES ($1,$2,$3,$4,$5)`,
        [pacUser[0].user_id,
         'Consulta Agendada',
         `A sua consulta foi agendada para ${new Date(data_hora).toLocaleString('pt-MZ')}. Senha nº ${senha}.`,
         'lembrete', rows[0].id]
      );
    }

    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro ao agendar consulta' });
  }
});

// PATCH /api/consultas/:id/status
router.patch('/:id/status', autenticar, autorizar('admin','recepcao','medico'), async (req, res) => {
  const { status } = req.body;
  const statusValidos = ['agendada','confirmada','em_atendimento','concluida','cancelada','falta'];
  if (!statusValidos.includes(status)) return res.status(400).json({ erro: 'Status inválido' });

  try {
    const { rows } = await db.query(
      'UPDATE consultas SET status=$1, updated_at=NOW() WHERE id=$2 RETURNING *',
      [status, req.params.id]
    );
    if (!rows.length) return res.status(404).json({ erro: 'Consulta não encontrada' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ erro: 'Erro interno' });
  }
});

// DELETE /api/consultas/:id  (cancelar)
router.delete('/:id', autenticar, autorizar('admin','recepcao'), async (req, res) => {
  try {
    await db.query('UPDATE consultas SET status=\'cancelada\', updated_at=NOW() WHERE id=$1', [req.params.id]);
    res.json({ mensagem: 'Consulta cancelada' });
  } catch (err) {
    res.status(500).json({ erro: 'Erro interno' });
  }
});

module.exports = router;
