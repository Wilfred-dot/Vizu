const router = require('express').Router();
const bcrypt = require('bcryptjs');
const db = require('../db');
const { autenticar, autorizar } = require('../middleware/auth');

// GET /api/pacientes
router.get('/', autenticar, autorizar('admin','recepcao','medico'), async (req, res) => {
  const { busca, pagina = 1, limite = 20 } = req.query;
  const offset = (pagina - 1) * limite;

  let query = `
    SELECT p.*, u.nome, u.email, u.telefone
    FROM pacientes p JOIN users u ON p.user_id = u.id
    WHERE u.ativo = TRUE
  `;
  const params = [];

  if (busca) {
    params.push(`%${busca}%`);
    query += ` AND (u.nome ILIKE $${params.length} OR p.num_processo ILIKE $${params.length})`;
  }
  query += ` ORDER BY u.nome LIMIT $${params.length+1} OFFSET $${params.length+2}`;
  params.push(limite, offset);

  try {
    const { rows } = await db.query(query, params);
    const total = await db.query('SELECT COUNT(*) FROM pacientes p JOIN users u ON p.user_id=u.id WHERE u.ativo=TRUE');
    res.json({ dados: rows, total: parseInt(total.rows[0].count), pagina: parseInt(pagina) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro ao buscar pacientes' });
  }
});

// GET /api/pacientes/:id
router.get('/:id', autenticar, async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT p.*, u.nome, u.email, u.telefone 
       FROM pacientes p JOIN users u ON p.user_id=u.id 
       WHERE p.id=$1`, [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ erro: 'Paciente não encontrado' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ erro: 'Erro interno' });
  }
});

// POST /api/pacientes  (criar paciente + user)
router.post('/', autenticar, autorizar('admin','recepcao'), async (req, res) => {
  const { nome, email, senha, telefone, data_nascimento, genero, morada, bairro, bi_numero, tipo_sanguineo, alergias } = req.body;

  if (!nome || !email || !data_nascimento) {
    return res.status(400).json({ erro: 'Nome, email e data de nascimento são obrigatórios' });
  }

  try {
    const senhaHash = await bcrypt.hash(senha || 'Paciente@2026', 10);

    // Gerar número de processo
    const { rows: count } = await db.query('SELECT COUNT(*) FROM pacientes');
    const numProcesso = `P-${new Date().getFullYear()}-${String(parseInt(count.rows[0].count)+1).padStart(4,'0')}`;

    await db.query('BEGIN');
    const { rows: userRows } = await db.query(
      'INSERT INTO users (nome, email, senha_hash, papel, telefone) VALUES ($1,$2,$3,$4,$5) RETURNING *',
      [nome, email, senhaHash, 'paciente', telefone]
    );
    const user = userRows[0];

    const { rows: pacRows } = await db.query(
      `INSERT INTO pacientes (user_id, num_processo, data_nascimento, genero, morada, bairro, bi_numero, tipo_sanguineo, alergias)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [user.id, numProcesso, data_nascimento, genero, morada, bairro, bi_numero, tipo_sanguineo, alergias]
    );
    await db.query('COMMIT');

    res.status(201).json({ ...pacRows[0], nome: user.nome, email: user.email, telefone: user.telefone });
  } catch (err) {
    await db.query('ROLLBACK');
    if (err.code === '23505') return res.status(409).json({ erro: 'Email já registado' });
    console.error(err);
    res.status(500).json({ erro: 'Erro ao criar paciente' });
  }
});

// PUT /api/pacientes/:id
router.put('/:id', autenticar, autorizar('admin','recepcao'), async (req, res) => {
  const { nome, telefone, data_nascimento, genero, morada, bairro, bi_numero, tipo_sanguineo, alergias } = req.body;
  try {
    const { rows: pac } = await db.query('SELECT * FROM pacientes WHERE id=$1', [req.params.id]);
    if (!pac.length) return res.status(404).json({ erro: 'Paciente não encontrado' });

    await db.query('UPDATE users SET nome=$1, telefone=$2, updated_at=NOW() WHERE id=$3',
      [nome, telefone, pac[0].user_id]);
    const { rows } = await db.query(
      `UPDATE pacientes SET data_nascimento=$1, genero=$2, morada=$3, bairro=$4, bi_numero=$5, tipo_sanguineo=$6, alergias=$7, updated_at=NOW()
       WHERE id=$8 RETURNING *`,
      [data_nascimento, genero, morada, bairro, bi_numero, tipo_sanguineo, alergias, req.params.id]
    );
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ erro: 'Erro ao actualizar paciente' });
  }
});

module.exports = router;
