const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const db = require('../db');

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const { email, senha } = req.body;
  if (!email || !senha) return res.status(400).json({ erro: 'Email e senha obrigatórios' });

  try {
    const { rows } = await db.query(
      'SELECT * FROM users WHERE email = $1 AND ativo = TRUE', [email]
    );
    if (!rows.length) return res.status(401).json({ erro: 'Credenciais inválidas' });

    const user = rows[0];
    const senhaCorreta = await bcrypt.compare(senha, user.senha_hash);
    if (!senhaCorreta) return res.status(401).json({ erro: 'Credenciais inválidas' });

    // Buscar dados extras segundo papel
    let dadosExtras = {};
    if (user.papel === 'paciente') {
      const { rows: p } = await db.query('SELECT * FROM pacientes WHERE user_id=$1', [user.id]);
      dadosExtras = p[0] || {};
    } else if (user.papel === 'medico') {
      const { rows: m } = await db.query('SELECT * FROM medicos WHERE user_id=$1', [user.id]);
      dadosExtras = m[0] || {};
    }

    const payload = { id: user.id, email: user.email, papel: user.papel, nome: user.nome };
    const accessToken = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '1h' });
    const refreshToken = jwt.sign({ id: user.id }, process.env.JWT_REFRESH_SECRET, { expiresIn: '7d' });

    // Guardar refresh token
    await db.query(
      'INSERT INTO refresh_tokens (user_id, token, expires_at) VALUES ($1, $2, NOW() + INTERVAL \'7 days\')',
      [user.id, refreshToken]
    );

    res.json({
      accessToken,
      refreshToken,
      usuario: { id: user.id, nome: user.nome, email: user.email, papel: user.papel, telefone: user.telefone, ...dadosExtras }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro interno' });
  }
});

// POST /api/auth/refresh
router.post('/refresh', async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(401).json({ erro: 'Refresh token requerido' });

  try {
    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    const { rows } = await db.query(
      'SELECT * FROM refresh_tokens WHERE token=$1 AND expires_at > NOW()', [refreshToken]
    );
    if (!rows.length) return res.status(403).json({ erro: 'Refresh token inválido' });

    const { rows: users } = await db.query('SELECT * FROM users WHERE id=$1', [decoded.id]);
    const user = users[0];
    const payload = { id: user.id, email: user.email, papel: user.papel, nome: user.nome };
    const accessToken = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h' });

    res.json({ accessToken });
  } catch (err) {
    res.status(403).json({ erro: 'Token inválido' });
  }
});

// POST /api/auth/logout
router.post('/logout', async (req, res) => {
  const { refreshToken } = req.body;
  if (refreshToken) {
    await db.query('DELETE FROM refresh_tokens WHERE token=$1', [refreshToken]);
  }
  res.json({ mensagem: 'Logout efectuado com sucesso' });
});

module.exports = router;
