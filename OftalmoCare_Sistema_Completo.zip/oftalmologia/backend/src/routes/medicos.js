// medicos.js
const router = require('express').Router();
const db = require('../db');
const { autenticar } = require('../middleware/auth');

router.get('/', autenticar, async (req, res) => {
  try {
    const { rows } = await db.query(
      'SELECT m.*, u.nome, u.email, u.telefone FROM medicos m JOIN users u ON m.user_id=u.id WHERE u.ativo=TRUE ORDER BY u.nome'
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ erro: 'Erro interno' });
  }
});

// Slots disponíveis para uma data
router.get('/:id/disponibilidade', autenticar, async (req, res) => {
  const { data } = req.query;
  if (!data) return res.status(400).json({ erro: 'Data é obrigatória' });

  try {
    const { rows: med } = await db.query('SELECT * FROM medicos WHERE id=$1', [req.params.id]);
    if (!med.length) return res.status(404).json({ erro: 'Médico não encontrado' });

    const { rows: ocupados } = await db.query(
      `SELECT data_hora FROM consultas WHERE medico_id=$1 AND DATE(data_hora)=$2 AND status NOT IN ('cancelada','falta')`,
      [req.params.id, data]
    );
    const horariosOcupados = ocupados.map(c => new Date(c.data_hora).toTimeString().slice(0, 5));

    // Gerar slots de 30min entre horario_inicio e horario_fim
    const slots = [];
    const [hIni, mIni] = med[0].horario_inicio.split(':').map(Number);
    const [hFim, mFim] = med[0].horario_fim.split(':').map(Number);
    let cur = hIni * 60 + mIni;
    const fim = hFim * 60 + mFim;

    while (cur < fim) {
      const h = String(Math.floor(cur / 60)).padStart(2, '0');
      const m = String(cur % 60).padStart(2, '0');
      const slot = `${h}:${m}`;
      slots.push({ hora: slot, disponivel: !horariosOcupados.includes(slot) });
      cur += 30;
    }
    res.json(slots);
  } catch (err) {
    res.status(500).json({ erro: 'Erro interno' });
  }
});

module.exports = router;
