const router = require('express').Router();
const db = require('../db');
const { autenticar, autorizar } = require('../middleware/auth');

router.get('/stats', autenticar, autorizar('admin','recepcao'), async (req, res) => {
  try {
    const [totalPacientes, totalHoje, agendadas, concluidas, canceladas] = await Promise.all([
      db.query('SELECT COUNT(*) FROM pacientes'),
      db.query(`SELECT COUNT(*) FROM consultas WHERE DATE(data_hora) = CURRENT_DATE`),
      db.query(`SELECT COUNT(*) FROM consultas WHERE DATE(data_hora) = CURRENT_DATE AND status IN ('agendada','confirmada')`),
      db.query(`SELECT COUNT(*) FROM consultas WHERE DATE(data_hora) = CURRENT_DATE AND status = 'concluida'`),
      db.query(`SELECT COUNT(*) FROM consultas WHERE DATE(data_hora) = CURRENT_DATE AND status = 'cancelada'`),
    ]);

    // Consultas por semana
    const { rows: semana } = await db.query(`
      SELECT DATE(data_hora) AS dia, COUNT(*) AS total
      FROM consultas
      WHERE data_hora >= NOW() - INTERVAL '7 days'
      GROUP BY DATE(data_hora) ORDER BY dia
    `);

    // Próximas consultas hoje
    const { rows: proximas } = await db.query(`
      SELECT c.*, up.nome AS paciente_nome, um.nome AS medico_nome, p.num_processo
      FROM consultas c
      JOIN pacientes p ON c.paciente_id=p.id JOIN users up ON p.user_id=up.id
      JOIN medicos m ON c.medico_id=m.id JOIN users um ON m.user_id=um.id
      WHERE DATE(c.data_hora)=CURRENT_DATE AND c.status IN ('agendada','confirmada')
      ORDER BY c.data_hora LIMIT 10
    `);

    res.json({
      totalPacientes: parseInt(totalPacientes.rows[0].count),
      consultasHoje: parseInt(totalHoje.rows[0].count),
      agendadas: parseInt(agendadas.rows[0].count),
      concluidas: parseInt(concluidas.rows[0].count),
      canceladas: parseInt(canceladas.rows[0].count),
      consultasSemana: semana,
      proximasConsultas: proximas,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro interno' });
  }
});

module.exports = router;
