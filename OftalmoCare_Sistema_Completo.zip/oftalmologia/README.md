# OftalmoCare — Sistema de Gestão de Saúde Oftalmológica

**Universidade Católica de Moçambique — Beira, 2026**  
**Autor:** Wilfred Deloviar Júnior  
**Supervisor:** Mestre Eng. Persson Domingos Abrantes

---

## Arquitectura do Sistema

```
oftalmologia/
├── database/        → Schema PostgreSQL
├── backend/         → API REST (Node.js + Express)
├── web/             → Dashboard Web (React)
└── mobile/          → Aplicação Móvel (React Native + Expo)
```

---

## 1. Base de Dados — PostgreSQL

### Instalar PostgreSQL
```bash
# Ubuntu/Debian
sudo apt install postgresql postgresql-contrib

# Windows: https://www.postgresql.org/download/windows/
```

### Criar base de dados e aplicar schema
```bash
sudo -u postgres psql
CREATE DATABASE oftalmologia_db;
CREATE USER oftalmologia_user WITH PASSWORD 'sua_senha_segura';
GRANT ALL PRIVILEGES ON DATABASE oftalmologia_db TO oftalmologia_user;
\q

psql -U oftalmologia_user -d oftalmologia_db -f database/schema.sql
```

**Tabelas criadas:**
- `users` — utilizadores (admin, recepção, médico, paciente)
- `pacientes` — dados clínicos dos pacientes
- `medicos` — dados profissionais dos médicos
- `consultas` — agendamentos e consultas
- `historico_clinico` — registos clínicos oftalmológicos
- `receitas` / `itens_receita` — prescrições médicas
- `exames` — pedidos e resultados de exames
- `notificacoes` — alertas e lembretes
- `refresh_tokens` — gestão de sessões JWT

---

## 2. Backend — Node.js + Express

### Instalação
```bash
cd backend
cp .env.example .env
# Editar .env com as credenciais da base de dados

npm install
npm run dev     # Desenvolvimento
npm start       # Produção
```

### Endpoints principais

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/api/auth/login` | Autenticação |
| POST | `/api/auth/refresh` | Renovar token |
| GET | `/api/pacientes` | Listar pacientes |
| POST | `/api/pacientes` | Registar paciente |
| GET | `/api/consultas` | Listar consultas |
| POST | `/api/consultas` | Agendar consulta |
| PATCH | `/api/consultas/:id/status` | Actualizar status |
| GET | `/api/historico/paciente/:id` | Histórico do paciente |
| POST | `/api/historico` | Criar registo clínico |
| GET | `/api/receitas/paciente/:id` | Receitas do paciente |
| POST | `/api/receitas` | Emitir receita |
| GET | `/api/notificacoes` | Notificações do utilizador |
| GET | `/api/dashboard/stats` | Estatísticas do painel |

### Autenticação (RBAC)
- **admin** — acesso total
- **recepcao** — gestão de pacientes e consultas
- **medico** — registo clínico e receitas
- **paciente** — visualização do seu próprio histórico

---

## 3. Web — React

### Instalação
```bash
cd web
npm install
npm start      # Desenvolvimento (porta 3000)
npm run build  # Produção
```

### Páginas
- `/login` — Autenticação
- `/dashboard` — Painel com estatísticas do dia
- `/pacientes` — Listagem e registo de pacientes
- `/consultas` — Gestão de consultas do dia
- `/consultas/nova` — Agendar nova consulta
- `/historico/:pacienteId` — Histórico clínico e receitas
- `/relatorios` — Relatórios (admin)

---

## 4. Mobile — React Native (Expo)

### Instalação
```bash
cd mobile
npm install

# Editar src/services/api.js:
# BASE_URL = 'http://SEU_IP_LOCAL:3001/api'

npx expo start
# Escanear QR code com Expo Go (Android/iOS)
```

### Telas
- **Login** — autenticação segura
- **Dashboard** — consultas do dia + notificações
- **Histórico Clínico** — registos oftalmológicos
- **Receitas** — prescrições com detalhes dos medicamentos

---

## Contas de Demonstração

| Utilizador | Email | Senha | Papel |
|-----------|-------|-------|-------|
| Admin | admin@oftalmologia.mz | admin123 | admin |
| Médico | joao.henriques@oftalmologia.mz | medico123 | medico |
| Recepcionista | ana.machava@oftalmologia.mz | recepcao123 | recepcao |
| Paciente | maria.fernanda@gmail.com | paciente123 | paciente |

---

## Stack Tecnológico

| Camada | Tecnologia |
|--------|-----------|
| Base de dados | PostgreSQL 15 |
| Backend | Node.js 18 + Express 4 |
| Autenticação | JWT (access + refresh tokens) |
| Web | React 18 + React Router 6 |
| Mobile | React Native + Expo + React Navigation |
| Segurança | bcryptjs, RBAC, HTTPS |

---

## Funcionalidades Implementadas

- ✅ Autenticação JWT com refresh tokens
- ✅ RBAC (controlo de acesso por papel)
- ✅ Cadastro e gestão de pacientes
- ✅ Agendamento de consultas com verificação de conflitos
- ✅ Gestão de fila com número de senha automático
- ✅ Histórico clínico oftalmológico (AV, PIO, biomicroscopia)
- ✅ Prescrições médicas digitais
- ✅ Notificações automáticas para pacientes
- ✅ Dashboard com estatísticas em tempo real
- ✅ App mobile para pacientes (iOS e Android)
- ✅ Disponibilidade de horários por médico

---

*Sistema desenvolvido como requisito parcial de conclusão do curso de Licenciatura em Tecnologias de Informação — UCM Beira, 2026.*
